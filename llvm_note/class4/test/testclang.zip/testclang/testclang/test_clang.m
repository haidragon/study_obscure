//
//  test_clang.m
//  testclang
//
//  Created by haidragon on 2020/1/6.
//  Copyright © 2020 haidragon. All rights reserved.
//

#import "test_clang.h"

@implementation test_clang
+ (void)test{
    NSLog(@"tset\n");
}
@end
