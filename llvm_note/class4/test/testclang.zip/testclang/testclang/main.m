//
//  main.m
//  testclang
//
//  Created by haidragon on 2020/1/5.
//  Copyright © 2020 haidragon. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        // Setup code that might create autoreleased objects goes here.
    }
    return NSApplicationMain(argc, argv);
}
