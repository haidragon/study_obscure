//
//  ViewController.h
//  testclang
//
//  Created by haidragon on 2020/1/5.
//  Copyright © 2020 haidragon. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface ViewController : NSViewController


@end

